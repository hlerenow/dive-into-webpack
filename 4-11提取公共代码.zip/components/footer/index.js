import React, {Component} from 'react';
import './index.css';

export class Footer extends Component {
  render() {
    return <footer>深入浅出 Webpack</footer>
  }
}
